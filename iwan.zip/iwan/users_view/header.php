<head>
	<title>IWAN BLOG</title>
	<link rel="stylesheet" href="users_view/style.css">
</head>

<div class="logo">
	<a href="index.php"> 
		<p>IWAN BLOG</p>
	</a>
</div>
<div id="menu">
	<a href="index.php">Home</a> | 
	<a href="subscribe.php">Subscribe</a>
</div>