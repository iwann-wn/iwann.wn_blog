<?php  
session_start();

require_once "users_function/db.php";
require_once "users_function/blog.php";
require_once "users_function/subs.php";


error_reporting(0);
error_reporting(E_ALL ^ E_WARNING || E_NOTICE);

?>